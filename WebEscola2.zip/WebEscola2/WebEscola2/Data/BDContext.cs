﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebEscola2.Models;

namespace WebEscola2.Data
{
    public class BDContext : DbContext
    {
        public BDContext (DbContextOptions<BDContext> options)
            : base(options)
        {
        }

        public DbSet<WebEscola2.Models.Instituicao> Instituicao { get; set; } = default!;

        public DbSet<WebEscola2.Models.Departamento> Departamento { get; set; } = default!;
    }
}
