﻿using System.ComponentModel.DataAnnotations;

namespace WebEscola2.Models
{
    public class Departamento
    {
        [Key]
        public int DepId { get; set; }
        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        public long? InstituicaoId { get; set; }
        public Instituicao Instituicao { get; set;}
    }
}
