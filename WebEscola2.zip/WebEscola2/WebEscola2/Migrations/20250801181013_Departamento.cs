﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebEscola2.Migrations
{
    /// <inheritdoc />
    public partial class Departamento : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Departamento",
                columns: table => new
                {
                    DepId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    InstituicaoId = table.Column<long>(type: "bigint", nullable: true),
                    InstituicaoInsituicaoId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Departamento", x => x.DepId);
                    table.ForeignKey(
                        name: "FK_Departamento_Instituicao_InstituicaoInsituicaoId",
                        column: x => x.InstituicaoInsituicaoId,
                        principalTable: "Instituicao",
                        principalColumn: "InsituicaoId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Departamento_InstituicaoInsituicaoId",
                table: "Departamento",
                column: "InstituicaoInsituicaoId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Departamento");
        }
    }
}
